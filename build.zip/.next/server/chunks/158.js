exports.id = 158;
exports.ids = [158];
exports.modules = {

/***/ 4034:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



const INITIAL_SIZE = 5; // *Component that replicates the MUI ripple effect

const Ripple = (_ref) => {
  let {
    rippleClassName,
    rippleContainerClassName,
    children,
    grow,
    disabled,
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["rippleClassName", "rippleContainerClassName", "children", "grow", "disabled", "className"]);

  const timer = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
  const {
    0: rippleStyle,
    1: setRippleStyle
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => () => {
    clearTimeout(timer.current);
  }, []);

  const handleClick = e => {
    const {
      pageX,
      pageY,
      currentTarget
    } = e;
    const bounds = currentTarget.getBoundingClientRect();
    const left = pageX - (bounds.left + window.scrollX);
    const top = pageY - (bounds.top + window.scrollY);
    const size = Math.max(bounds.width, bounds.height);
    setRippleStyle(() => {
      timer.current = setTimeout(() => {
        setRippleStyle({
          left,
          top,
          opacity: 0,
          transform: `scale(${size / INITIAL_SIZE * 2})`,
          transition: 'all 1000ms'
        });
      }, 50);
      return {
        left,
        top,
        transform: 'translate(-50%, -50%)',
        transition: 'initial',
        opacity: 1
      };
    });
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", _objectSpread(_objectSpread({
    onMouseDown: handleClick,
    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('relative isolate cursor-pointer', grow ? 'grid' : 'max-w-max flex', className)
  }, rest), {}, {
    children: [children, !disabled && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('absolute inset-0 pointer-events-none overflow-hidden', rippleContainerClassName),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: rippleStyle,
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('rounded-full absolute w-1 h-1 opacity-0', rippleClassName || 'bg-white bg-opacity-50')
      })
    })]
  }));
};

/* harmony default export */ __webpack_exports__["Z"] = (Ripple);

/***/ }),

/***/ 4317:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Yu": function() { return /* binding */ getData; },
/* harmony export */   "q9": function() { return /* binding */ getDataServerside; },
/* harmony export */   "qC": function() { return /* binding */ postData; }
/* harmony export */ });
/* unused harmony exports getHeaders, patchData */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const getHeaders = () => {
  const token = localStorage.getItem('token');
  if (!token) return null;
  const headers = {
    Authorization: `Bearer ${token}`
  };
  return headers;
}; // NOTE: PUT YOUR IP ADDRESS HERE

const getData = async (url, data) => {
  console.log("https://coursereview.co.nz");
  const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${"https://coursereview.co.nz"}/${url}`, _objectSpread({
    headers: getHeaders()
  }, data && {
    params: data
  })).then(response => response).catch(error => {
    console.log(error);

    if (!(error !== null && error !== void 0 && error.response)) {
      // in case the server goes down or something, instead of saying undefined give this error
      throw new Error('Sorry the server is currently sleeping, come back later');
    }

    throw new Error(`${error.response.status}: ${error.response.data.message}`);
  });
  return response;
};
const getDataServerside = async (url, data) => {
  console.log("https://coursereview.co.nz");
  const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${"https://coursereview.co.nz"}/${url}`, _objectSpread({}, data && {
    params: data
  })).then(response => response).catch(error => {
    console.log(error);

    if (!(error !== null && error !== void 0 && error.response)) {
      // in case the server goes down or something, instead of saying undefined give this error
      throw new Error('Sorry the server is currently sleeping, come back later');
    }

    throw new Error(`${error.response.status}: ${error.response.data.message}`);
  });
  return response;
};
const postData = async (url, data = {}) => {
  const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${window.location.origin}/${url}`, data, {
    headers: getHeaders()
  }).then(response => response).catch(error => {
    console.log(error);

    if (!(error !== null && error !== void 0 && error.response)) {
      throw new Error('Sorry the server is currently sleeping, come back later');
    }

    throw new Error(`${error.response.status}: ${error.response.data.message}`);
  });
  return response;
};
const patchData = async (url, data = {}) => {
  const response = await axios.patch(`${window.location.origin}/${url}`, data, {
    headers: getHeaders()
  }).then(response => response).catch(error => {
    if (!(error !== null && error !== void 0 && error.response)) {
      throw new Error('Sorry the server is currently sleeping, come back later');
    }

    throw new Error(`${error.response.status}: ${error.response.data.message}`);
  });
  return response;
};

/***/ }),

/***/ 6879:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": function() { return /* binding */ codeToURL; }
/* harmony export */ });
const codeToURL = code => code.replace(' ', '').replace('/', '%2F').toLowerCase();

/***/ }),

/***/ 4453:
/***/ (function() {

/* (ignored) */

/***/ })

};
;