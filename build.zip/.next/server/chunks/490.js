exports.id = 490;
exports.ids = [490];
exports.modules = {

/***/ 6922:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connection = {};

async function connectDB() {
  if (connection.isConnected) {
    // Use current db connection
    return;
  } // Use new db connection


  const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true
  });
  connection.isConnected = db.connections[0].readyState;
  console.log(connection.isConnected);
}

/* harmony default export */ __webpack_exports__["Z"] = (connectDB);

/***/ }),

/***/ 9521:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ initMiddleware; }
/* harmony export */ });
function initMiddleware(middleware) {
  return (req, res) => new Promise((resolve, reject) => {
    middleware(req, res, result => {
      if (result instanceof Error) {
        return reject(result);
      }

      return resolve(result);
    });
  });
}

/***/ }),

/***/ 7164:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const reviewSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  taken_date: {
    type: String,
    required: true
  },
  content: {
    type: String,

    validate(value) {
      if (value.length > 1000) {
        throw new Error('The word limit is 200');
      }
    }

  },
  course_rating: {
    type: Number,
    required: true
  },
  content_rating: {
    type: Number,
    required: true
  },
  workload_rating: {
    type: Number,
    required: true
  },
  delivery_rating: {
    type: Number,
    required: true
  },
  upvote: {
    type: Number,
    default: 0
  },
  downvote: {
    type: Number,
    default: 0
  },
  owner: {
    type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
    required: true,
    ref: 'Course'
  }
}, {
  timestamps: true
});
(mongoose__WEBPACK_IMPORTED_MODULE_0___default().models) = {};
const Review = mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Review', reviewSchema);
/* harmony default export */ __webpack_exports__["Z"] = (Review);

/***/ })

};
;