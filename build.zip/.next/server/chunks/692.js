exports.id = 692;
exports.ids = [692];
exports.modules = {

/***/ 6922:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connection = {};

async function connectDB() {
  if (connection.isConnected) {
    // Use current db connection
    return;
  } // Use new db connection


  const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true
  });
  connection.isConnected = db.connections[0].readyState;
  console.log(connection.isConnected);
}

/* harmony default export */ __webpack_exports__["Z"] = (connectDB);

/***/ }),

/***/ 1778:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const courseSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  id: {
    type: Number
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  code: {
    type: String,
    required: true,
    trim: true
  },
  pageId: {
    type: String,
    required: true,
    trim: true
  },
  university: {
    type: String,
    required: true,
    trim: true
  },
  faculty: {
    type: String,
    required: true,
    trim: true
  },
  url: {
    type: String
  },
  requirements: {
    type: String
  },
  term: [{
    type: Number
  }],
  assessments: [{
    name: {
      type: String
    },
    percentage: {
      type: Number
    }
  }]
});
courseSchema.virtual('reviews', {
  ref: 'Review',
  localField: '_id',
  foreignField: 'owner'
});
(mongoose__WEBPACK_IMPORTED_MODULE_0___default().models) = {};
const Course = mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Course', courseSchema);
/* harmony default export */ __webpack_exports__["Z"] = (Course);

/***/ })

};
;