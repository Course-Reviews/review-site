exports.id = 494;
exports.ids = [494];
exports.modules = {

/***/ 7494:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



const Logo = (_ref) => {
  let {
    className,
    fill
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["className", "fill"]);

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", _objectSpread(_objectSpread({
    width: "242",
    height: "193",
    viewBox: "0 0 242 193",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    className: className
  }, rest), {}, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
      id: "Course Review Logo",
      children: "Course Review Logo "
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("desc", {
      id: "logoDesc",
      children: "Purple gradient letters C R for course review logos positioned asymmetrically."
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M28.8 66.4C28.8 42.6 46.5 23.9 69.5 23.9C80.4 23.9 90.8 27.9 98.8 35.3L114.5 17.6C102.2 6.3 86.2 0 69.5 0C46.8 0 19.5 15 19.5 43.5C19.5 54.8 24 66.3 29.4 73.7C29 71.3 28.8 68.9 28.8 66.4ZM0 66.3C0 59.1 1.2 52.2 3.4 45.7C5.9 82.2 31.8 108.5 65 108.4C76.8 108.4 90.3 104.6 99.7 98.2L114.6 115C102.3 126.4 86.3 132.7 69.5 132.7C31.9 132.7 0 104 0 66.3ZM235.5 109.7C235.5 126.1 226.4 140.3 212.9 147.8L242 192.2H215.8L190.4 153.3H189.4H156.2V192.1H133V66H184.7C201.3 66 217.8 72.9 217.8 88.2C217.8 97.1 213.7 104.4 208.1 109.8V109.6C208.1 98.4 198.8 89.2 187.3 89.2H156.2V130.1H195.7C216.5 130.1 229.2 115.2 233.8 97.7C234.9 101.5 235.5 105.6 235.5 109.7Z",
      fill: fill || 'url(#paint0_linear)'
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
        id: "paint0_linear",
        x1: "14",
        y1: "192",
        x2: "237.582",
        y2: "14.496",
        gradientUnits: "userSpaceOnUse",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
          stopColor: "#6F40FF"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
          offset: "1",
          stopColor: "#C240FF"
        })]
      })
    })]
  }));
};

/* harmony default export */ __webpack_exports__["Z"] = (Logo);

/***/ })

};
;