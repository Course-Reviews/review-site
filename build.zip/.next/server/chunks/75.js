exports.id = 75;
exports.ids = [75];
exports.modules = {

/***/ 7075:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6893);
/* harmony import */ var react_mixpanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9208);
/* harmony import */ var react_mixpanel__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_mixpanel__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _functions_fetchSearchResults__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9892);
/* harmony import */ var _atom_Expand__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4773);
/* harmony import */ var _atom_Ripple__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4034);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(153);
/* harmony import */ var _SearchResult__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7877);











// This is how long we should wait after each keypress before actually executing the search
const SEARCH_DELAY = 500; // Dont search until the user has typed at least this many characters

const SEARCH_LENGTH_THRESHOLD = 2;

const CourseSearch = ({
  className
}) => {
  // When we do a search cache the results in a map
  // * We might want to think abt making sure the cache doesnt exceed a certain number of entries but it should be fine
  const cache = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(new Map()); // Stores a list of search results

  const {
    0: searchResults,
    1: setSearchResults
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]); // The value of the users current search

  const {
    0: searchValue,
    1: setSearchValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(''); // Tracks if the search is in the loading state

  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false); // const universities: string[] = ['UoA', 'Massey', 'AUT', 'VIC', 'Otago'];
  // The timer tracks how long it has been since the user has typed

  const timer = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(0); // Side effect of searchValue changing

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    window.clearTimeout(timer.current); // Cancel the search if it is too short

    if (searchValue.length < SEARCH_LENGTH_THRESHOLD) {
      return setLoading(false);
    } // first attempt to get result from cache to save api calls


    if (cache.current.has(searchValue)) {
      setLoading(false);
      setSearchResults(cache.current.get(searchValue));
    } else {
      setLoading(true);
      timer.current = window.setTimeout(async () => {
        // if we get to this point then we do the actual search
        const res = await (0,_functions_fetchSearchResults__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(searchValue);
        cache.current.set(searchValue, res);
        setSearchResults(res);
        setLoading(false);
      }, SEARCH_DELAY);
    }
  }, [searchValue]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('w-full md:max-w-xl mb-2 mx-auto px-8 h-16', className),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
      className: "container flex flex-col rounded-full relative",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atom_Ripple__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
        className: 'bg-white rounded-full ',
        grow: true,
        rippleClassName: 'bg-primary-200',
        rippleContainerClassName: "rounded-full",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "focus-within:ring-4 focus-within:ring-primary-500 pl-6 my-auto flex items-center border rounded-full shadow-lg relative z-10",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__/* .FiSearch */ .jRj, {
            size: 24,
            className: 'text-primary-600',
            strokeWidth: 3
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_mixpanel__WEBPACK_IMPORTED_MODULE_3__.MixpanelConsumer, {
            children: mixpanel => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
              type: "text",
              className: "px-6 focus:outline-none w-full py-4 bg-transparent text-xl",
              autoFocus: true,
              placeholder: "ACCTG 102",
              value: searchValue,
              onChange: e => {
                var _e$target, _e$target2;

                mixpanel.track('[LANDING] Searching', {
                  value: (_e$target = e.target) === null || _e$target === void 0 ? void 0 : _e$target.value
                });
                setSearchValue(((_e$target2 = e.target) === null || _e$target2 === void 0 ? void 0 : _e$target2.value) || '');
              }
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: loading ? 'opacity-100' : 'opacity-0',
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
              className: "mx-4"
            })
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mt-2 text-center inset-x-0 absolute top-16 z-10",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atom_Expand__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
          expanded: searchValue.length >= SEARCH_LENGTH_THRESHOLD,
          className: "w-full mx-auto shadow-xl rounded-lg",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "w-full bg-white ",
            children: loading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: 'py-2 px-3',
              children: "loading..."
            }) : searchResults.length > 0 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_mixpanel__WEBPACK_IMPORTED_MODULE_3__.MixpanelConsumer, {
              children: mixpanel => searchResults.map(result => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchResult__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
                onClick: () => {
                  mixpanel.track('[LANDING] Course Clicked', {
                    value: result.code
                  });
                },
                result: result,
                isCondensed: false,
                className: "bg-white"
              }, result.id))
            }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "bg-white shadow rounded-lg py-2 ",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: "No results."
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center flex-col my-4 ",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                  className: "my-4",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_9__/* .FiInfo */ .H33, {
                    size: "20"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                  children: "Is your course not here?"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_mixpanel__WEBPACK_IMPORTED_MODULE_3__.MixpanelConsumer, {
                  children: mixpanel => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-info-600 my-2",
                    onClick: () => {},
                    children: "Please tell us!"
                  })
                })]
              })]
            })
          })
        })
      })]
    })
  });
};

/* harmony default export */ __webpack_exports__["Z"] = (CourseSearch);

/***/ }),

/***/ 153:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(471);



const Loader = props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
  className: `animate-spin  ${props.className}`,
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_cg__WEBPACK_IMPORTED_MODULE_1__/* .CgSpinner */ .frZ, {})
});

/* harmony default export */ __webpack_exports__["Z"] = (Loader);

/***/ }),

/***/ 7877:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _UniTag__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7591);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6893);
/* harmony import */ var _util_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6879);







const SearchResult = ({
  result,
  className,
  isCondensed,
  onClick
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
  href: `/courses/${result.university}/${(0,_util_util__WEBPACK_IMPORTED_MODULE_3__/* .codeToURL */ .U)(result.code)}`,
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
    onClick: onClick,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
      className: `hover:bg-gray-100 flex items-center w-full justify-between py-2 my-2 px-4 ${className}`,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center",
        children: [!isCondensed && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: "text-primary-800",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__/* .FiSearch */ .jRj, {})
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
          className: "px-2 font-semibold uppercase text-gray-800",
          children: result.code
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-1/4 text-right",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UniTag__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
          uni: result.university
        })
      })]
    })
  })
}, result.id);

/* harmony default export */ __webpack_exports__["Z"] = (SearchResult);

/***/ }),

/***/ 7591:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);



const UniTag = props =>
/*#__PURE__*/
// Uni tag shows which university an item belongs to and is primarily used in filters and search results
// Todo improve color contrast for certain unis
react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
  className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(`text-${props.uni.toLocaleLowerCase()} text-white rounded-full font-bold text-sm py-1`, props.className),
  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
    className: "uppercase",
    children: props.uni
  })
});

/* harmony default export */ __webpack_exports__["Z"] = (UniTag);

/***/ }),

/***/ 9892:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4317);


const fetchSearchResults = async (query, filters) => {
  // eslint-disable-next-line quotes
  console.log(query);
  const {
    data
  } = await (0,___WEBPACK_IMPORTED_MODULE_0__/* .getData */ .Yu)(`api/search/${query.trim()}${filters ? `?${Object.entries(filters).map(([k, v]) => `${k}=${v}`)}` : ''}`);
  return data;
};

/* harmony default export */ __webpack_exports__["Z"] = (fetchSearchResults);

/***/ })

};
;