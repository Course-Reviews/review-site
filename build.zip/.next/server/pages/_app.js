(function() {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7534:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _app; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "async-modals"
var external_async_modals_ = __webpack_require__(9896);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: external "mixpanel-browser"
var external_mixpanel_browser_namespaceObject = require("mixpanel-browser");;
var external_mixpanel_browser_default = /*#__PURE__*/__webpack_require__.n(external_mixpanel_browser_namespaceObject);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react-mixpanel"
var external_react_mixpanel_ = __webpack_require__(9208);
;// CONCATENATED MODULE: external "react-toastify"
var external_react_toastify_namespaceObject = require("react-toastify");;
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(8819);
// EXTERNAL MODULE: ./components/atom/Container.tsx
var Container = __webpack_require__(7135);
;// CONCATENATED MODULE: ./components/atom/Navbar.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const Navbar = (_ref) => {
  let {
    noBg,
    children,
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["noBg", "children", "className"]);

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("header", _objectSpread(_objectSpread({
      className: external_classnames_default()(noBg ? 'bg-gray-50' : 'bg-white shadow-lg', 'flex items-center sticky top-0 left-0 h-16 z-30 mb-2 ', className)
    }, rest), {}, {
      children: children
    }))
  });
};

/* harmony default export */ var atom_Navbar = (Navbar);
// EXTERNAL MODULE: ./node_modules/react-icons/fi/index.esm.js
var index_esm = __webpack_require__(6893);
// EXTERNAL MODULE: external "react-useanimations"
var external_react_useanimations_ = __webpack_require__(8927);
var external_react_useanimations_default = /*#__PURE__*/__webpack_require__.n(external_react_useanimations_);
// EXTERNAL MODULE: external "react-useanimations/lib/radioButton"
var radioButton_ = __webpack_require__(2695);
var radioButton_default = /*#__PURE__*/__webpack_require__.n(radioButton_);
// EXTERNAL MODULE: ./components/atom/Button.tsx
var Button = __webpack_require__(6715);
// EXTERNAL MODULE: ./components/atom/FormGroup.tsx
var FormGroup = __webpack_require__(1418);
// EXTERNAL MODULE: ./components/atom/Input.tsx
var Input = __webpack_require__(1535);
// EXTERNAL MODULE: ./components/atom/Modal.tsx
var Modal = __webpack_require__(165);
;// CONCATENATED MODULE: ./components/FeedbackModal.tsx











const PostReviewModal = ({
  data = {},
  isClosing,
  cancel
}) => {
  const {
    0: message,
    1: setMessage
  } = (0,external_react_.useState)(data.prefilled);
  const {
    0: submitted,
    1: setSubmitted
  } = (0,external_react_.useState)(false);

  const handleSubmit = e => {
    e.preventDefault();
    setSubmitted(true);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Modal/* default */.Z, {
    isClosing: isClosing,
    className: 'w-full sm:w-3/4 md:w-2/3 lg:max-w-lg m-4',
    children: [/*#__PURE__*/jsx_runtime_.jsx(Modal/* default.Title */.Z.Title, {
      close: cancel,
      children: "Give us Feedback"
    }), submitted ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: 'flex flex-col items-center text-primary-500 my-8',
      children: [/*#__PURE__*/jsx_runtime_.jsx((external_react_useanimations_default()), {
        reverse: true,
        size: 100,
        animation: (radioButton_default()),
        strokeColor: 'currentColor',
        speed: 0.75
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: 'text-lg font-bold my-8',
        children: "Thanks for the feedback!"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Button/* default */.Z, {
        onClick: cancel,
        children: ["Continue browsing Courses", /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiArrowRight */.Rgz, {
          size: 24,
          className: 'ml-2 -m-2'
        })]
      })]
    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      onSubmit: handleSubmit,
      children: [/*#__PURE__*/jsx_runtime_.jsx(FormGroup/* default */.Z, {
        label: "Message",
        children: /*#__PURE__*/jsx_runtime_.jsx(Input/* default */.Z, {
          as: "textarea",
          placeholder: "Something we can do better? Want to request a feature? Let us know!",
          className: 'h-48',
          onChange: e => setMessage(e.target.value)
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: 'flex flex-col mt-4 first:mt-0',
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          block: true,
          onClick: () => {// mixpanel.track('[REVIEW MODAL] Post');
          },
          children: "Send Feedback"
        })
      })]
    })]
  });
};

/* harmony default export */ var FeedbackModal = (PostReviewModal);
;// CONCATENATED MODULE: ./components/Footer.tsx







const Footer = () => {
  const modal = (0,external_async_modals_.useModal)(FeedbackModal);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    className: "flex flex-col md:flex-row w-full text-center px-4 py-4 text-gray-600 bottom-0 justify-between",
    children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
      children: "Copyright \xA9 2021 CourseReview"
    }), /*#__PURE__*/jsx_runtime_.jsx("button", {
      onClick: () => modal.show(),
      className: "font-semibold text-primary-600 my-2 md:my-0",
      children: "Leave Feedback"
    }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "/terms-and-conditions",
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: 'underline',
        children: "Terms and Conditions"
      })
    })]
  });
};

/* harmony default export */ var components_Footer = (Footer);
// EXTERNAL MODULE: ./components/Logo.tsx
var Logo = __webpack_require__(7494);
// EXTERNAL MODULE: ./functions/fetchSearchResults.tsx
var fetchSearchResults = __webpack_require__(9892);
// EXTERNAL MODULE: ./components/atom/Expand.tsx
var Expand = __webpack_require__(4773);
// EXTERNAL MODULE: ./components/atom/Ripple.tsx
var Ripple = __webpack_require__(4034);
// EXTERNAL MODULE: ./components/Loader.tsx
var Loader = __webpack_require__(153);
// EXTERNAL MODULE: ./components/SearchResult.tsx
var SearchResult = __webpack_require__(7877);
;// CONCATENATED MODULE: ./components/NavSearch.tsx










 // This is how long we should wait after each keypress before actually executing the search

const SEARCH_DELAY = 500; // Dont search until the user has typed at least this many characters

const SEARCH_LENGTH_THRESHOLD = 2;

const NavSearch = ({
  className
}) => {
  const {
    0: searchResults,
    1: setSearchResults
  } = (0,external_react_.useState)([]);
  const cache = (0,external_react_.useRef)(new Map());
  const {
    0: focused,
    1: setFocused
  } = (0,external_react_.useState)(false);
  const {
    0: searchValue,
    1: setSearchValue
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false); // const universities: string[] = ['UoA', 'Massey', 'AUT', 'VIC', 'Otago'];
  // The timer tracks how long it has been since the user has typed

  const timer = (0,external_react_.useRef)(0); // Side effect of searchValue changing

  (0,external_react_.useEffect)(() => {
    window.clearTimeout(timer.current); // Cancel the search if it is too short

    if (searchValue.length < SEARCH_LENGTH_THRESHOLD) {
      return setLoading(false);
    } // first attempt to get result from cache to save api calls


    if (cache.current.has(searchValue)) {
      setLoading(false);
      setSearchResults(cache.current.get(searchValue));
    } else {
      setLoading(true);
      timer.current = window.setTimeout(async () => {
        // if we get to this point then we do the actual search
        const res = await (0,fetchSearchResults/* default */.Z)(searchValue);
        setSearchResults(res);
        setLoading(false);
      }, SEARCH_DELAY);
    }
  }, [searchValue]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: external_classnames_default()('transition-width bg-gray-100 flex items-center rounded-full', focused ? 'w-72' : 'w-48', className),
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Ripple/* default */.Z, {
      className: 'w-full md:max-w-md mx-auto ',
      grow: true,
      rippleClassName: 'bg-primary-200',
      rippleContainerClassName: "rounded-full",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center w-full relative z-10",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "pl-3",
          children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiSearch */.jRj, {
            size: 20
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(external_react_mixpanel_.MixpanelConsumer, {
          children: mixpanel => /*#__PURE__*/jsx_runtime_.jsx("input", {
            className: "px-2 focus:outline-none w-full py-2  bg-transparent",
            onFocus: () => setFocused(true),
            value: searchValue,
            placeholder: "Search Courses",
            onChange: e => {
              var _e$target, _e$target2;

              setSearchValue(((_e$target = e.target) === null || _e$target === void 0 ? void 0 : _e$target.value) || '');
              mixpanel.track('[NAV] Search ', {
                value: (_e$target2 = e.target) === null || _e$target2 === void 0 ? void 0 : _e$target2.value
              });
            },
            onBlur: () => searchValue.length < SEARCH_LENGTH_THRESHOLD && setFocused(false)
          })
        }), searchValue.length >= SEARCH_LENGTH_THRESHOLD && loading && /*#__PURE__*/jsx_runtime_.jsx(Loader/* default */.Z, {
          className: "mx-4"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(Expand/* default */.Z, {
        expanded: searchValue.length >= SEARCH_LENGTH_THRESHOLD,
        className: "absolute mt-12 px-2 rounded-lg w-full shadow-lg text-gray-700 transition-height bg-white",
        children: focused && searchValue.length > SEARCH_LENGTH_THRESHOLD && /*#__PURE__*/jsx_runtime_.jsx("ul", {
          className: "w-full py-1",
          children: !loading ? searchResults.length > 0 ? /*#__PURE__*/jsx_runtime_.jsx(external_react_mixpanel_.MixpanelConsumer, {
            children: mixpanel => searchResults.map(result => /*#__PURE__*/jsx_runtime_.jsx("div", {
              onClick: () => setSearchValue(''),
              children: /*#__PURE__*/jsx_runtime_.jsx(SearchResult/* default */.Z, {
                result: result,
                isCondensed: true,
                onClick: () => {
                  mixpanel.track('[NAV] Course Clicked', {
                    value: result.code
                  });
                }
              })
            }, result.id))
          }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: 'py-2 my-2 px-4',
            children: "No Results"
          }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: 'py-2 my-2 px-4',
            children: "Loading..."
          })
        })
      })]
    })
  });
};

/* harmony default export */ var components_NavSearch = (NavSearch);
// EXTERNAL MODULE: ./components/atom/IconButton.tsx
var IconButton = __webpack_require__(999);
;// CONCATENATED MODULE: ./components/ScrollToTop.tsx







const ScrollToTop = ({}) => {
  const {
    0: show,
    1: setShow
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    const listener = () => {
      const scrollTop = window.scrollY;

      if (scrollTop > 0 && !show) {
        setShow(true);
      } else if (scrollTop <= 0 && show) {
        setShow(false);
      }
    };

    document.addEventListener('scroll', listener);
    return () => document.removeEventListener('scroll', listener);
  }, [show]);

  const handleClick = () => {
    window.scrollTo({
      top: 0
    }); // setShow(false);
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: external_classnames_default()('fixed bottom-0 left:0 md:right-0 m-5 z-20', show ? 'animate-float-in' : 'animate-float-out opacity-0'),
    children: /*#__PURE__*/jsx_runtime_.jsx(IconButton/* default */.Z, {
      icon: index_esm/* FiArrowUp */.iRh,
      onClick: handleClick
    })
  });
};

/* harmony default export */ var components_ScrollToTop = (ScrollToTop);
// EXTERNAL MODULE: ./components/CourseSearch.tsx
var CourseSearch = __webpack_require__(7075);
;// CONCATENATED MODULE: ./components/SearchModal.tsx







const SearchModal = ({
  isClosing,
  cancel
}) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
  className: external_classnames_default()(isClosing ? 'animate-float-out' : 'animate-float-in', 'w-full h-full bg-white p-4'),
  children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
    className: 'text-gray-800 flex items-center justify-end -mx-1',
    children: /*#__PURE__*/jsx_runtime_.jsx("button", {
      onClick: cancel,
      children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiX */.q5L, {
        size: 24
      })
    })
  }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
    className: 'text-lg font-bold text-gray-700 text-center my-4',
    children: "Search all courses"
  }), /*#__PURE__*/jsx_runtime_.jsx(CourseSearch/* default */.Z, {})]
});

/* harmony default export */ var components_SearchModal = (SearchModal);
;// CONCATENATED MODULE: ./components/SearchButton.tsx







const SearchButton = ({
  className
}) => {
  const modal = (0,external_async_modals_.useModal)(components_SearchModal);
  return /*#__PURE__*/jsx_runtime_.jsx(IconButton/* default */.Z, {
    innerClassName: className,
    variant: "none",
    icon: index_esm/* FiSearch */.jRj,
    onClick: () => modal.show()
  });
};

/* harmony default export */ var components_SearchButton = (SearchButton);
;// CONCATENATED MODULE: ./pages/_app.tsx



function _app_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _app_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { _app_ownKeys(Object(source), true).forEach(function (key) { _app_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { _app_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _app_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



















const MyApp = ({
  Component,
  pageProps
}) => {
  external_mixpanel_browser_default().init('08d4d7028dcc32f1449375dc93c154c7');
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_mixpanel_.MixpanelProvider, {
    mixpanel: (external_mixpanel_browser_default()),
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "apple-touch-icon",
        sizes: "180x180",
        href: "/apple-touch-icon.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        type: "image/png",
        sizes: "32x32",
        href: "/favicon-32x32.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        type: "image/png",
        sizes: "16x16",
        href: "/favicon-16x16.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "manifest",
        href: "/site.webmanifest"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(external_async_modals_.ModalProvider, {
      backgroundClassName: isExiting => external_classnames_default()('fixed inset-0 bg-gray-900 bg-opacity-75 flex justify-center items-center z-40', isExiting ? 'animate-modal-bg-fade-out' : 'animate-modal-bg-fade-in'),
      exitDelay: 200,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "bg-gray-50 min-h-screen select-none flex flex-col justify-between",
        children: [/*#__PURE__*/jsx_runtime_.jsx(atom_Navbar, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container/* default */.Z, {
            className: 'flex justify-between',
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                className: 'flex items-center h-8',
                children: [/*#__PURE__*/jsx_runtime_.jsx(Logo/* default */.Z, {
                  className: 'h-12 w-12 mx-4'
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: 'text-gray-700 font-semibold',
                  children: "Course Reviews"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(components_SearchButton, {
              className: 'sm:hidden'
            }), " ", /*#__PURE__*/jsx_runtime_.jsx(components_NavSearch, {
              className: 'hidden sm:flex'
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(Component, _app_objectSpread({}, pageProps)), /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {}), /*#__PURE__*/jsx_runtime_.jsx(components_ScrollToTop, {})]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(external_react_toastify_namespaceObject.ToastContainer, {})]
  });
};

/* harmony default export */ var _app = (MyApp);

/***/ }),

/***/ 8819:
/***/ (function() {



/***/ }),

/***/ 9896:
/***/ (function(module) {

"use strict";
module.exports = require("async-modals");;

/***/ }),

/***/ 2376:
/***/ (function(module) {

"use strict";
module.exports = require("axios");;

/***/ }),

/***/ 4058:
/***/ (function(module) {

"use strict";
module.exports = require("classnames");;

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 9208:
/***/ (function(module) {

"use strict";
module.exports = require("react-mixpanel");;

/***/ }),

/***/ 8927:
/***/ (function(module) {

"use strict";
module.exports = require("react-useanimations");;

/***/ }),

/***/ 2695:
/***/ (function(module) {

"use strict";
module.exports = require("react-useanimations/lib/radioButton");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [597,675,608,471,529,158,135,16,494,714,75,918], function() { return __webpack_exec__(7534); });
module.exports = __webpack_exports__;

})();