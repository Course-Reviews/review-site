(function() {
var exports = {};
exports.id = 746;
exports.ids = [746];
exports.modules = {

/***/ 8267:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _id_; },
  "getStaticPaths": function() { return /* binding */ getStaticPaths; },
  "getStaticProps": function() { return /* binding */ getStaticProps; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "async-modals"
var external_async_modals_ = __webpack_require__(9896);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/react-icons/fi/index.esm.js
var index_esm = __webpack_require__(6893);
// EXTERNAL MODULE: external "react-mixpanel"
var external_react_mixpanel_ = __webpack_require__(9208);
// EXTERNAL MODULE: ./components/atom/Expand.tsx
var Expand = __webpack_require__(4773);
// EXTERNAL MODULE: ./components/atom/IconButton.tsx
var IconButton = __webpack_require__(999);
;// CONCATENATED MODULE: ./components/atom/Accordian.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const Accordian = (_ref) => {
  let {
    children,
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["children", "className"]);

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: external_classnames_default()('mb-2', className),
    children: children
  });
};

const AccordianItem = (_ref2) => {
  let {
    children,
    expanded: e = false,
    className
  } = _ref2,
      rest = _objectWithoutProperties(_ref2, ["children", "expanded", "className"]);

  const {
    0: expanded,
    1: setExpanded
  } = (0,external_react_.useState)(e);
  return /*#__PURE__*/jsx_runtime_.jsx("section", _objectSpread(_objectSpread({
    className: external_classnames_default()('flex flex-col mt-2 first:mt-0', className)
  }, rest), {}, {
    children: external_react_default().Children.map(children, child => /*#__PURE__*/external_react_default().createElement(child === null || child === void 0 ? void 0 : child.type, _objectSpread(_objectSpread({}, child.props), {}, {
      expanded,
      setExpanded
    })))
  }));
};

const AccordianHeader = (_ref3) => {
  let {
    children,
    className,
    expanded,
    setExpanded
  } = _ref3,
      rest = _objectWithoutProperties(_ref3, ["children", "className", "expanded", "setExpanded"]);

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: () => setExpanded && setExpanded(v => !v),
    className: external_classnames_default()('cursor-pointer flex items-center justify-between py-1 px-1 border-b hover:bg-gray-50 rounded-t-lg', className),
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      children: children
    }), /*#__PURE__*/jsx_runtime_.jsx(IconButton/* default */.Z, {
      size: 'sm',
      variant: "none",
      icon: index_esm/* FiChevronDown */.bTu,
      innerClassName: external_classnames_default()('transform transition-transform', !expanded && '-rotate-90')
    })]
  });
};

const AccordianBody = (_ref4) => {
  let {
    expanded,
    children,
    className,
    setExpanded
  } = _ref4,
      rest = _objectWithoutProperties(_ref4, ["expanded", "children", "className", "setExpanded"]);

  return /*#__PURE__*/jsx_runtime_.jsx(Expand/* default */.Z, _objectSpread(_objectSpread({
    expanded: expanded
  }, rest), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: 'flex flex-col pt-4',
      children: children
    })
  }));
};

/* harmony default export */ var atom_Accordian = (Object.assign(Accordian, {
  Item: AccordianItem,
  Header: AccordianHeader,
  Body: AccordianBody
}));
// EXTERNAL MODULE: ./components/atom/BreadCrumbs.tsx
var BreadCrumbs = __webpack_require__(1070);
// EXTERNAL MODULE: ./components/atom/Button.tsx
var Button = __webpack_require__(6715);
// EXTERNAL MODULE: ./components/atom/Card.tsx + 1 modules
var Card = __webpack_require__(9529);
// EXTERNAL MODULE: ./components/atom/Col.tsx
var Col = __webpack_require__(2030);
// EXTERNAL MODULE: ./components/atom/Container.tsx
var Container = __webpack_require__(7135);
// EXTERNAL MODULE: ./components/atom/Row.tsx
var Row = __webpack_require__(713);
// EXTERNAL MODULE: ./components/atom/StarRating.tsx
var StarRating = __webpack_require__(427);
// EXTERNAL MODULE: external "react-useanimations"
var external_react_useanimations_ = __webpack_require__(8927);
var external_react_useanimations_default = /*#__PURE__*/__webpack_require__.n(external_react_useanimations_);
// EXTERNAL MODULE: external "react-useanimations/lib/radioButton"
var radioButton_ = __webpack_require__(2695);
var radioButton_default = /*#__PURE__*/__webpack_require__.n(radioButton_);
// EXTERNAL MODULE: ./functions/index.js
var functions = __webpack_require__(4317);
;// CONCATENATED MODULE: ./functions/postReview.tsx


const postReview = async (courseId, data) => {
  try {
    const res = await (0,functions/* postData */.qC)(`api/posts/${courseId}/`, data);
    return res.data;
  } catch (e) {
    console.log(e);
  } // return data;

};

/* harmony default export */ var functions_postReview = (postReview);
;// CONCATENATED MODULE: ./types/config.ts
let Uni;

(function (Uni) {
  Uni["UOA"] = "uoa";
  Uni["MUA"] = "mua";
  Uni["VIC"] = "vic";
  Uni["OTAGO"] = "otago";
})(Uni || (Uni = {}));

const TERMS = ['Summer School', 'Academic Year Term', 'Quarter 1', 'Semester 1', 'Quarter 2', 'Semester 2', 'Quarter 3', 'Later Year Term', 'Quarter 4', 'Doctoral Academic Year'];
// EXTERNAL MODULE: ./components/atom/Ripple.tsx
var Ripple = __webpack_require__(4034);
;// CONCATENATED MODULE: ./components/atom/Dropdown.tsx



function Dropdown_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Dropdown_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Dropdown_ownKeys(Object(source), true).forEach(function (key) { Dropdown_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Dropdown_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Dropdown_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function Dropdown_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = Dropdown_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function Dropdown_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const Dropdown = (_ref) => {
  let {
    options,
    children,
    onChange,
    selectedIndex = 0,
    disabled
  } = _ref,
      rest = Dropdown_objectWithoutProperties(_ref, ["options", "children", "onChange", "selectedIndex", "disabled"]);

  selectedIndex = selectedIndex === -1 ? 0 : selectedIndex;
  const {
    0: focused,
    1: setFocused
  } = (0,external_react_.useState)(false);
  const {
    0: option,
    1: setOption
  } = (0,external_react_.useState)(options[selectedIndex]);
  (0,external_react_.useEffect)(() => {
    if (onChange) {
      onChange(option);
    }
  }, [option]);
  (0,external_react_.useEffect)(() => {
    if (selectedIndex) {
      setOption(options[selectedIndex]);
    }
  }, [selectedIndex]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: 'relative w-full',
    children: [/*#__PURE__*/jsx_runtime_.jsx(Ripple/* default */.Z, {
      disabled: disabled,
      grow: true,
      rippleClassName: 'bg-primary-200',
      rippleContainerClassName: "rounded-xl",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", Dropdown_objectSpread(Dropdown_objectSpread({
        type: "button",
        "aria-expanded": focused,
        className: 'bg-transparent border border-gray-300 px-3 py-2 rounded-xl focus:outline-none focus:ring focus:ring-primary-300 relative z-10 flex items-center text-gray-800',
        onClick: () => setFocused(v => !v),
        onBlur: () => setFocused(false)
      }, rest), {}, {
        children: [option.label, /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiChevronDown */.bTu, {
          className: 'ml-2 absolute right-3',
          size: 20
        })]
      }))
    }), /*#__PURE__*/jsx_runtime_.jsx(Expand/* default */.Z, {
      expanded: focused,
      className: 'bg-white absolute z-10 shadow-lg rounded-lg mt-2 w-full',
      children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
        className: 'p-2 divide-y divide-gray-200',
        children: options.map((v, i) => /*#__PURE__*/jsx_runtime_.jsx("li", {
          onClick: () => setOption(v),
          className: 'p-1 px-3 cursor-pointer hover:bg-gray-100 ',
          children: v.label
        }, i))
      })
    })]
  });
};

/* harmony default export */ var atom_Dropdown = (Dropdown);
// EXTERNAL MODULE: ./components/atom/FormGroup.tsx
var FormGroup = __webpack_require__(1418);
// EXTERNAL MODULE: ./components/atom/Input.tsx
var Input = __webpack_require__(1535);
// EXTERNAL MODULE: ./components/atom/Modal.tsx
var Modal = __webpack_require__(165);
;// CONCATENATED MODULE: ./components/atom/RatingInput.tsx


function RatingInput_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function RatingInput_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { RatingInput_ownKeys(Object(source), true).forEach(function (key) { RatingInput_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { RatingInput_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function RatingInput_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function RatingInput_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = RatingInput_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function RatingInput_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const RatingInput = (_ref) => {
  let {
    size = 28,
    onChange,
    className
  } = _ref,
      rest = RatingInput_objectWithoutProperties(_ref, ["size", "onChange", "className"]);

  const {
    0: r,
    1: setR
  } = (0,external_react_.useState)(0);
  const {
    0: hoverNum,
    1: setHoverNum
  } = (0,external_react_.useState)(0);
  (0,external_react_.useEffect)(() => {
    if (onChange) {
      onChange(r);
    }
  }, [r]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", RatingInput_objectSpread(RatingInput_objectSpread({
    className: external_classnames_default()('flex', className)
  }, rest), {}, {
    onMouseLeave: () => setHoverNum(0),
    children: [1, 2, 3, 4, 5].map((e, i) => /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiStar */.nae, {
      size: size,
      className: external_classnames_default()('cursor-pointer mx-0.5', r >= e ? 'text-primary-500' : hoverNum >= e ? 'text-primary-200' : 'text-gray-600'),
      fill: r >= e || hoverNum >= e ? 'currentColor' : 'none',
      onClick: () => setR(e),
      onMouseOver: () => setHoverNum(e)
    }, i))
  }));
};

/* harmony default export */ var atom_RatingInput = (RatingInput);
;// CONCATENATED MODULE: ./components/PostReviewModal.tsx



function PostReviewModal_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function PostReviewModal_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { PostReviewModal_ownKeys(Object(source), true).forEach(function (key) { PostReviewModal_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { PostReviewModal_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function PostReviewModal_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















const YEARS = ['2020', '2021'];

const PostReviewModal = ({
  data,
  isClosing,
  cancel,
  submit
}) => {
  let termIndex = data.terms.findIndex(v => v === 3 || v === 5);
  if (termIndex === -1) termIndex = 0;
  const {
    0: formdata,
    1: setFormdata
  } = (0,external_react_.useState)({
    term: termIndex
  });
  const {
    0: formerrors,
    1: setFormerrors
  } = (0,external_react_.useState)({});
  const {
    0: submitted,
    1: setSubmitted
  } = (0,external_react_.useState)(false);
  const {
    0: review,
    1: setReview
  } = (0,external_react_.useState)(); // const review = useRef<fetchReviewsResponse>();

  const handleSubmit = async e => {
    e.preventDefault();
    const {
      workloadRating,
      contentRating,
      deliveryRating,
      content,
      term,
      year
    } = formdata; // validation

    const errors = {};

    if (!workloadRating) {
      errors.workloadRating = 'Please choose a rating for workload';
    }

    if (!contentRating) {
      errors.contentRating = 'Please choose a rating for content';
    }

    if (!deliveryRating) {
      errors.deliveryRating = 'Please choose a rating for delivery';
    }

    if (content && content.length > 1000) {
      errors.content = `Reviews are limited to 1000 characters (currently ${content.length})`;
    }

    setFormerrors(errors);

    if (Object.keys(errors).length > 0) {
      return;
    }

    console.log('Posting!');
    setSubmitted(true);
    const res = await functions_postReview(data.courseId, {
      course_rating: (workloadRating + deliveryRating + contentRating) / 3,
      content,
      taken_date: `${TERMS[term]} ${year}`,
      workload_rating: workloadRating,
      content_rating: contentRating,
      delivery_rating: deliveryRating
    });
    setReview(res);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Modal/* default */.Z, {
    isClosing: isClosing,
    className: 'w-full sm:w-3/4 md:w-2/3 lg:max-w-lg m-4',
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Modal/* default.Title */.Z.Title, {
      close: cancel,
      children: ["Review ", data.code]
    }), review ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: 'flex flex-col items-center text-primary-500 my-8',
      children: [/*#__PURE__*/jsx_runtime_.jsx((external_react_useanimations_default()), {
        reverse: true,
        size: 100,
        animation: (radioButton_default()),
        strokeColor: 'currentColor',
        speed: 0.75
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: 'text-lg font-bold my-8',
        children: "Thanks for leaving a review!"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Button/* default */.Z, {
        onClick: () => review ? submit(review) : cancel(),
        children: ["Back to ", data.code, /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiArrowRight */.Rgz, {
          size: 24,
          className: 'ml-2 -m-2'
        })]
      })]
    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      onSubmit: handleSubmit,
      children: [/*#__PURE__*/jsx_runtime_.jsx(FormGroup/* default */.Z, {
        label: "Taken In",
        required: true,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Row/* default */.Z, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(Col/* default */.Z, {
            className: 'w-2/3 md:w-1/2',
            children: /*#__PURE__*/jsx_runtime_.jsx(atom_Dropdown, {
              options: data.terms.map(t => ({
                label: TERMS[t],
                value: t
              })),
              selectedIndex: termIndex,
              onChange: v => setFormdata(d => PostReviewModal_objectSpread(PostReviewModal_objectSpread({}, d), {}, {
                term: v.value
              }))
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(Col/* default */.Z, {
            className: 'w-1/3 md:w-1/2',
            children: /*#__PURE__*/jsx_runtime_.jsx(atom_Dropdown, {
              options: YEARS.map(v => ({
                label: v,
                value: v
              })),
              selectedIndex: 1,
              onChange: v => setFormdata(d => PostReviewModal_objectSpread(PostReviewModal_objectSpread({}, d), {}, {
                year: v.value
              }))
            })
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(FormGroup/* default */.Z, {
        label: "Workload",
        required: true,
        error: formerrors.workloadRating,
        children: /*#__PURE__*/jsx_runtime_.jsx(atom_RatingInput, {
          className: 'mt-1',
          onChange: v => setFormdata(d => PostReviewModal_objectSpread(PostReviewModal_objectSpread({}, d), {}, {
            workloadRating: v
          }))
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(FormGroup/* default */.Z, {
        label: "Content Quality",
        required: true,
        error: formerrors.contentRating,
        children: /*#__PURE__*/jsx_runtime_.jsx(atom_RatingInput, {
          className: 'mt-1',
          onChange: v => setFormdata(d => PostReviewModal_objectSpread(PostReviewModal_objectSpread({}, d), {}, {
            contentRating: v
          }))
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(FormGroup/* default */.Z, {
        label: "Delivery of Content",
        required: true,
        error: formerrors.deliveryRating,
        children: /*#__PURE__*/jsx_runtime_.jsx(atom_RatingInput, {
          className: 'mt-1',
          onChange: v => setFormdata(d => PostReviewModal_objectSpread(PostReviewModal_objectSpread({}, d), {}, {
            deliveryRating: v
          }))
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(FormGroup/* default */.Z, {
        label: "Review",
        error: formerrors.content,
        children: /*#__PURE__*/jsx_runtime_.jsx(Input/* default */.Z, {
          as: "textarea",
          placeholder: "Provide a written review (optional)",
          className: 'h-48',
          onChange: e => setFormdata(d => PostReviewModal_objectSpread(PostReviewModal_objectSpread({}, d), {}, {
            content: e.target.value
          }))
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: 'flex flex-col mt-4 first:mt-0',
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          block: true,
          onClick: () => {// mixpanel.track('[REVIEW MODAL] Post');
          },
          disabled: submitted,
          children: submitted ? 'Posting...' : 'Post Anonymous Review'
        })
      })]
    })]
  });
};

/* harmony default export */ var components_PostReviewModal = (PostReviewModal);
;// CONCATENATED MODULE: ./components/Review.tsx










const Review = ({
  highlight,
  review: {
    rating,
    timeTaken,
    content,
    votes,
    contentRating,
    workloadRating,
    deliveryRating
  }
}) => /*#__PURE__*/jsx_runtime_.jsx(external_react_mixpanel_.MixpanelConsumer, {
  children: mixpanel => /*#__PURE__*/jsx_runtime_.jsx(Card/* default */.Z, {
    className: external_classnames_default()('mb-4', highlight && 'ring-4 ring-primary-500'),
    as: "article",
    itemProp: "review",
    itemScope: true,
    itemType: "https://schema.org/Review",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Card/* default.Body */.Z.Body, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: 'flex items-center text-sm font-bold text-gray-500',
        children: [/*#__PURE__*/jsx_runtime_.jsx(StarRating/* default */.Z, {
          rating: rating,
          size: 20,
          className: 'text-secondary-500 mr-2'
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          itemProp: "reviewRating",
          itemScope: true,
          itemType: "https://schema.org/Rating",
          className: 'text-gray-500',
          children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
            itemProp: "worstRating",
            content: "1"
          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
            itemProp: "ratingValue",
            children: Math.round(rating * 10) / 10
          }), "/", /*#__PURE__*/jsx_runtime_.jsx("span", {
            itemProp: "bestRating",
            children: "5"
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: 'flex-grow'
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: 'text-gray-500',
          children: timeTaken
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: 'flex text-center mt-3 mb-1 divide-x',
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: 'w-1/3',
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: 'font-bold text-primary-500',
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: 'text-2xl',
              children: contentRating
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: 'text-sm text-primary-300',
              children: "/5"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: 'mt-0.5 text-xs font-semibold text-gray-500',
            children: "Content"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: 'w-1/3',
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: 'font-bold text-primary-500',
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: 'text-2xl',
              children: workloadRating
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: 'text-sm text-primary-300',
              children: "/5"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: 'mt-0.5 text-xs font-semibold text-gray-500',
            children: "Workload"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: 'w-1/3',
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: 'font-bold text-primary-500',
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: 'text-2xl',
              children: deliveryRating
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: 'text-sm text-primary-300',
              children: "/5"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: 'mt-0.5 text-xs font-semibold text-gray-500',
            children: "Delivery"
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("section", {
        className: 'flex flex-col',
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          itemProp: "reviewBody",
          className: 'mt-2 whitespace-pre-line',
          children: content
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
        className: 'flex justify-between mb-2',
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          itemProp: "author",
          className: ' text-gray-400 italic font-semibold',
          children: "- Anonymous"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: " "
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: 'flex border-t pt-2',
        children: [/*#__PURE__*/jsx_runtime_.jsx(IconButton/* default */.Z, {
          variant: "none",
          onClick: () => {
            mixpanel.track('[REVIEW] report', {
              value: content
            });
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiFlag */.MJI, {
            size: 24,
            className: 'text-gray-700'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: 'flex-grow'
        }), /*#__PURE__*/jsx_runtime_.jsx(IconButton/* default */.Z, {
          variant: "none",
          icon: index_esm/* FiThumbsDown */.oLd
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: 'mx-4 font-bold text-gray-700',
          children: votes
        }), ' ', /*#__PURE__*/jsx_runtime_.jsx(IconButton/* default */.Z, {
          variant: "none",
          icon: index_esm/* FiThumbsUp */.fmn
        })]
      })]
    })
  })
});

/* harmony default export */ var components_Review = (Review);
;// CONCATENATED MODULE: ./functions/fetchCourse.tsx
 // this fetches literally every single course in the databse

const fetchCourse = async (uni, code) => {
  const {
    data
  } = await (0,functions/* getDataServerside */.q9)(`api/courses?uni=${uni}&code=${code}`);
  return data;
};

/* harmony default export */ var functions_fetchCourse = (fetchCourse);
;// CONCATENATED MODULE: ./functions/fetchReviews.tsx


const fetchReviews = async courseId => {
  const {
    data
  } = await (0,functions/* getData */.Yu)(`api/posts/${courseId}`);
  return data;
};

/* harmony default export */ var functions_fetchReviews = (fetchReviews);
// EXTERNAL MODULE: ./util/util.ts
var util = __webpack_require__(6879);
;// CONCATENATED MODULE: ./pages/courses/[uni]/[id].tsx























const Course = ({
  id,
  code,
  title,
  overview,
  url,
  rating,
  numRatings,
  assessments,
  requirements,
  university,
  term
}) => {
  const {
    0: reviewData,
    1: setReviewData
  } = (0,external_react_.useState)({
    rating,
    numRatings
  });
  const messageModal = (0,external_async_modals_.useModal)(components_PostReviewModal);
  const {
    0: reviews,
    1: setReviews
  } = (0,external_react_.useState)();
  (0,external_react_.useEffect)(() => {
    const hydrate = async () => {
      const data = await functions_fetchReviews(id);
      const processed = data.map(e => ({
        id: e._id,
        rating: e.course_rating,
        content: e.content,
        timeTaken: e.taken_date,
        dateCreated: new Date(e.createdAt),
        votes: e.upvote - e.downvote,
        contentRating: e.content_rating,
        workloadRating: e.workload_rating,
        deliveryRating: e.delivery_rating
      }));
      setReviews(processed);
    };

    hydrate();
  }, []);

  const showModal = async () => {
    const review = await messageModal.show({
      data: {
        terms: term,
        code,
        courseId: id
      },
      canClose: false
    });

    if (review) {
      const processedReview = {
        id: review._id,
        rating: review.course_rating,
        content: review.content,
        timeTaken: review.taken_date,
        dateCreated: new Date(review.createdAt),
        votes: 0,
        contentRating: review.content_rating,
        workloadRating: review.workload_rating,
        deliveryRating: review.delivery_rating
      };
      setReviews(r => [...(r || []), processedReview]);
      setReviewData(d => ({
        rating: (d.rating * d.numRatings + review.course_rating) / (d.numRatings + 1),
        numRatings: d.numRatings + 1
      }));
    }
  }; // Detects course codes in text and replaces them with links


  const renderLinkedCourses = r => {
    const res = [];
    const regex = /[A-Z]+\s[0-9](?:[0-9]|\s|,|or|and)+[0-9]/gm;
    const matches = r.match(regex);
    if (!matches) return r;
    let i = 0;

    for (const m of matches) {
      // push all text up to the start of the match group
      const startLoc = r.indexOf(m);
      res.push( /*#__PURE__*/jsx_runtime_.jsx("span", {
        children: r.substring(i, startLoc)
      }, i));
      i = startLoc;
      const course = m.match(/[A-Z]+/)[0];
      const strings = m.match(/(?:[A-Z]+\s)?[0-9]{3}/g);

      for (const str of strings) {
        // find the absolute position from the start of the string
        const absStrPos = m.indexOf(str) + startLoc;

        if (i < absStrPos) {
          // push any text before the link not yet included
          res.push( /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: r.substring(i, absStrPos)
          }, i));
          i = absStrPos;
        }

        const newCode = `${course}${str.replace(/[^0-9]*/g, '')}`;
        const link = `/courses/${university.toLowerCase()}/${(0,util/* codeToURL */.U)(newCode)}`;
        res.push( /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: link,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: 'text-primary-500 underline',
            children: str
          })
        }, i));
        i += str.length;
      }
    }

    return res;
  };

  return /*#__PURE__*/jsx_runtime_.jsx(external_react_mixpanel_.MixpanelConsumer, {
    children: mixpanel => /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container/* default */.Z, {
      as: 'main',
      className: 'pb-24 flex-grow',
      itemScope: true,
      itemType: 'https://schema.org/UserReview',
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("title", {
          children: [code, " ", university, " - Course Review"]
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "keywords",
          content: `${code} review, ${title} review, course review`
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "description",
          content: `Check out what other students had to say about ${code} ${title} and related course reviews for The University of Auckland.`
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "keywords",
          content: ` ${code}, ${code} course reviews, ${code} uoa course, ${title} review`
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "robots",
          content: "index,follow"
        }), /*#__PURE__*/jsx_runtime_.jsx("link", {
          rel: "icon",
          href: "/favicon.ico"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(Row/* default */.Z, {
        className: 'my-2',
        children: /*#__PURE__*/jsx_runtime_.jsx(Col/* default */.Z, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(BreadCrumbs/* default */.Z, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(BreadCrumbs/* default.Home */.Z.Home, {}), /*#__PURE__*/jsx_runtime_.jsx(BreadCrumbs/* default.Item */.Z.Item, {
              href: "/courses",
              children: "Courses"
            }), /*#__PURE__*/jsx_runtime_.jsx(BreadCrumbs/* default.Item */.Z.Item, {
              href: '/courses/uoa',
              children: "UoA"
            }), /*#__PURE__*/jsx_runtime_.jsx(BreadCrumbs/* default.Item */.Z.Item, {
              href: `/courses/uoa/${(0,util/* codeToURL */.U)(code)}`,
              children: code
            })]
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Row/* default */.Z, {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Col/* default */.Z, {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
            className: 'text-2xl font-bold text-gray-800',
            children: [code, " - ", title]
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: 'text-sm text-gray-400 font-semibold',
            children: "The University of Auckland"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: 'flex items-center my-4',
            children: [/*#__PURE__*/jsx_runtime_.jsx(StarRating/* default */.Z, {
              className: external_classnames_default()(reviewData.rating ? 'text-secondary-500' : 'text-gray-500', 'mr-4'),
              rating: reviewData.rating || 0,
              size: 30
            }), ' ', /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: 'text-gray-600 max-h-min',
              children: reviewData.rating ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                itemScope: true,
                itemType: "https://schema.org/AggregateRating",
                itemProp: "aggregateRating",
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  itemProp: "ratingValue",
                  children: Math.round(reviewData.rating * 10) / 10
                }), "/", /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: "5"
                }), ' ', /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
                  itemProp: "reviewCount",
                  children: ["(", reviewData.numRatings, " rating", reviewData.numRatings === 1 ? '' : 's', ")"]
                })]
              }) : 'No ratings yet'
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(Col/* default */.Z, {
          className: 'items-end fixed md:static bottom-0 left-0 p-6 md:p-0 z-10',
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Button/* default */.Z, {
            onClick: showModal,
            children: [/*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiStar */.nae, {
              size: 24,
              className: '-m-2 mr-2'
            }), "Leave a review"]
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(Row/* default */.Z, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Col/* default */.Z, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
            className: 'text-xl font-bold text-gray-800 flex items-center my-2',
            children: [/*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiBook */.yK7, {
              className: 'mr-2'
            }), "Course Info"]
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(Row/* default */.Z, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Col/* default */.Z, {
          children: /*#__PURE__*/jsx_runtime_.jsx(Card/* default */.Z, {
            children: /*#__PURE__*/jsx_runtime_.jsx(Card/* default.Body */.Z.Body, {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(atom_Accordian, {
                children: [(url || overview) && /*#__PURE__*/(0,jsx_runtime_.jsxs)(atom_Accordian.Item, {
                  expanded: true,
                  children: [/*#__PURE__*/jsx_runtime_.jsx(atom_Accordian.Header, {
                    children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                      className: 'text-lg font-semibold text-gray-700',
                      children: "Course Overview"
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(atom_Accordian.Body, {
                    children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                      className: 'text-gray-700',
                      children: overview
                    }), url && /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: 'flex',
                      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                        className: 'text-primary-400 text-sm font-semibold hover:text-primary-500 flex p-2 underline',
                        href: url,
                        target: 'uoa_site',
                        children: [/*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiExternalLink */.AlO, {
                          size: 20,
                          className: 'mr-1'
                        }), "Official UoA site for ", code]
                      })
                    })]
                  })]
                }), requirements && /*#__PURE__*/(0,jsx_runtime_.jsxs)(atom_Accordian.Item, {
                  children: [/*#__PURE__*/jsx_runtime_.jsx(atom_Accordian.Header, {
                    children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                      className: 'text-lg font-semibold text-gray-700',
                      children: "Prerequisites"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(atom_Accordian.Body, {
                    children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                      className: 'text-gray-700',
                      children: renderLinkedCourses(requirements)
                    })
                  })]
                }), assessments && /*#__PURE__*/(0,jsx_runtime_.jsxs)(atom_Accordian.Item, {
                  children: [/*#__PURE__*/jsx_runtime_.jsx(atom_Accordian.Header, {
                    children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                      className: 'text-lg font-semibold text-gray-700',
                      children: "Assessments"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(atom_Accordian.Body, {
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("table", {
                      className: 'text-gray-600 mx-auto w-full md:w-1/2',
                      children: [/*#__PURE__*/jsx_runtime_.jsx("thead", {
                        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                          children: [/*#__PURE__*/jsx_runtime_.jsx("th", {
                            className: 'text-left',
                            children: "Assessment"
                          }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                            children: "Weighting"
                          })]
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("tbody", {
                        children: assessments.map((v, i) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                          className: external_classnames_default()(i % 2 && ' rounded-xl'),
                          children: [/*#__PURE__*/jsx_runtime_.jsx("td", {
                            className: external_classnames_default()(i % 2 && 'rounded-l-xl bg-gray-100', 'px-4 py-2 '),
                            children: v.name
                          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                            className: external_classnames_default()(i % 2 && 'rounded-r-xl bg-gray-100', 'px-4 py-2 text-center '),
                            children: [v.percentage, "%"]
                          })]
                        }, i))
                      })]
                    })
                  })]
                })]
              })
            })
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(Row/* default */.Z, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Col/* default */.Z, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
            className: 'text-xl font-bold text-gray-800 flex items-center my-4',
            children: [/*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiMessageSquare */.IC0, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: 'mx-2',
              children: "Reviews"
            })]
          })
        })
      }), reviews ? reviews.length > 0 ? reviews.sort((a, b) => b.dateCreated.getTime() - a.dateCreated.getTime()).map((r, i) => /*#__PURE__*/jsx_runtime_.jsx(components_Review, {
        review: r
      }, i)) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: 'w-2/3 mx-auto text-center flex flex-col items-center text-lg font-semibold text-gray-400 mt-6',
        children: [/*#__PURE__*/jsx_runtime_.jsx(index_esm/* FiInbox */.ND7, {
          className: 'my-2',
          size: 30
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: "Nobody has written a reivew for this course yet"
        }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          outline: true,
          className: 'mt-4',
          onClick: () => {
            showModal();
            mixpanel.track(`'['${code}']' Click review  `);
          },
          children: "Be the first"
        })]
      }) : [0, 1].map((v, i) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: 'bg-gray-100 animate-pulse my-4 rounded-xl p-4 flex flex-col',
        children: [/*#__PURE__*/jsx_runtime_.jsx(StarRating/* default */.Z, {
          rating: 5,
          className: 'text-gray-200'
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: 'h-3 mt-3 bg-gray-200 w-1/2 rounded-full'
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: 'h-3 mt-3 bg-gray-200 w-1/3 rounded-full'
        })]
      }, i))]
    })
  });
};

/* harmony default export */ var _id_ = (Course);
/**
 * Disabling this for now since we dont want to make 3000+ db calls to build our app,
 * so easiest solution is to just render when the page is requested
 */

const getStaticPaths = async () => ({
  paths: [],
  fallback: 'blocking'
}) // return({
// paths: (courses as any).map((v: any) => ({
//   params: {
//     uni: v.university,
//     id: v.code.replace(' ', '').toLowerCase(),
//   },
// })),
// fallback: false,
// })
;
const getStaticProps = async ({
  params
}) => {
  const {
    id,
    uni
  } = params;
  const data = await functions_fetchCourse(uni, id);
  return {
    props: data,
    revalidate: 60
  };
};

/***/ }),

/***/ 9896:
/***/ (function(module) {

"use strict";
module.exports = require("async-modals");;

/***/ }),

/***/ 2376:
/***/ (function(module) {

"use strict";
module.exports = require("axios");;

/***/ }),

/***/ 4058:
/***/ (function(module) {

"use strict";
module.exports = require("classnames");;

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 6731:
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 9208:
/***/ (function(module) {

"use strict";
module.exports = require("react-mixpanel");;

/***/ }),

/***/ 8927:
/***/ (function(module) {

"use strict";
module.exports = require("react-useanimations");;

/***/ }),

/***/ 2695:
/***/ (function(module) {

"use strict";
module.exports = require("react-useanimations/lib/radioButton");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [597,675,608,529,158,135,16,714,303,918], function() { return __webpack_exec__(8267); });
module.exports = __webpack_exports__;

})();