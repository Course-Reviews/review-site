(function() {
var exports = {};
exports.id = 520;
exports.ids = [520];
exports.modules = {

/***/ 6883:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _models_review__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7164);
/* harmony import */ var _db_mongoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6922);
/* harmony import */ var express_rate_limit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7472);
/* harmony import */ var express_rate_limit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_rate_limit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rate_limit_mongo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8014);
/* harmony import */ var rate_limit_mongo__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rate_limit_mongo__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _middleware_initMiddleware__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9521);
// needs the review id, easily exploitable





const limiter = (0,_middleware_initMiddleware__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(new (express_rate_limit__WEBPACK_IMPORTED_MODULE_2___default())({
  store: new (rate_limit_mongo__WEBPACK_IMPORTED_MODULE_3___default())({
    uri: process.env.MONGO_URI,
    // should match windowMs
    expireTimeMs: 60 * 60 * 1000,
    errorHandler: console.error.bind(null, 'rate-limit-mongo') // see Configuration section for more options and details

  }),
  windowMs: 60 * 60 * 1000,
  max: 20
}));
(0,_db_mongoose__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)();

const handler = async (req, res) => {
  if (req.method === 'PATCH') {
    await limiter(req, res);
    const url = req.url.split('/');

    switch (url[5]) {
      case 'upvote':
        try {
          const review = await _models_review__WEBPACK_IMPORTED_MODULE_0__/* .default.findByIdAndUpdate */ .Z.findByIdAndUpdate(url[4], {
            $inc: {
              upvote: 1
            }
          }, {
            new: true
          });
          res.status(200).json(review);
        } catch (e) {
          res.status(400).json(e);
        }

        break;

      case 'downvote':
        try {
          const review = await _models_review__WEBPACK_IMPORTED_MODULE_0__/* .default.findByIdAndUpdate */ .Z.findByIdAndUpdate(url[4], {
            $inc: {
              downvote: 1
            }
          }, {
            new: true
          });
          res.status(200).json(review);
        } catch (e) {
          res.status(400).json(e);
        }

        break;

      default:
        res.status(400).json({
          success: false
        });
    }
  }
};

/* harmony default export */ __webpack_exports__["default"] = (handler);

/***/ }),

/***/ 7472:
/***/ (function(module) {

"use strict";
module.exports = require("express-rate-limit");;

/***/ }),

/***/ 5619:
/***/ (function(module) {

"use strict";
module.exports = require("mongoose");;

/***/ }),

/***/ 8014:
/***/ (function(module) {

"use strict";
module.exports = require("rate-limit-mongo");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [490], function() { return __webpack_exec__(6883); });
module.exports = __webpack_exports__;

})();