(function() {
var exports = {};
exports.id = 590;
exports.ids = [590];
exports.modules = {

/***/ 3500:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _models_review__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7164);
/* harmony import */ var _db_mongoose__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6922);
/* harmony import */ var express_rate_limit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7472);
/* harmony import */ var express_rate_limit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(express_rate_limit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rate_limit_mongo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8014);
/* harmony import */ var rate_limit_mongo__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rate_limit_mongo__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _middleware_initMiddleware__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9521);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// a post request for a post on a course (needs the course id)






const limiter = (0,_middleware_initMiddleware__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)(new (express_rate_limit__WEBPACK_IMPORTED_MODULE_3___default())({
  store: new (rate_limit_mongo__WEBPACK_IMPORTED_MODULE_4___default())({
    uri: process.env.MONGO_URI,
    // should match windowMs
    expireTimeMs: 60 * 60 * 1000,
    errorHandler: console.error.bind(null, 'rate-limit-mongo') // see Configuration section for more options and details

  }),
  windowMs: 60 * 60 * 1000,
  max: 20
}));
(0,_db_mongoose__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z)();

const handler = async (req, res) => {
  if (req.method === 'POST') {
    await limiter(req, res);
    const review = new _models_review__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z(_objectSpread(_objectSpread({}, req.body), {}, {
      owner: mongoose__WEBPACK_IMPORTED_MODULE_0___default().Types.ObjectId(req.query.courseId)
    }));

    try {
      await review.save();
      res.status(201).json(review);
    } catch (e) {
      res.status(400).json(e.errors.content.properties.message);
    }
  }

  if (req.method === 'GET') {
    // Fetch all reviews for a given course
    try {
      const reviews = await _models_review__WEBPACK_IMPORTED_MODULE_1__/* .default.find */ .Z.find({
        owner: req.query.courseId,
        content: {
          $exists: true
        }
      });
      res.status(200).json(reviews);
    } catch (e) {
      res.status(400).json(e.errors.content.properties.message);
    }
  }
};

/* harmony default export */ __webpack_exports__["default"] = (handler);

/***/ }),

/***/ 7472:
/***/ (function(module) {

"use strict";
module.exports = require("express-rate-limit");;

/***/ }),

/***/ 5619:
/***/ (function(module) {

"use strict";
module.exports = require("mongoose");;

/***/ }),

/***/ 8014:
/***/ (function(module) {

"use strict";
module.exports = require("rate-limit-mongo");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [490], function() { return __webpack_exec__(3500); });
module.exports = __webpack_exports__;

})();