(function() {
var exports = {};
exports.id = 755;
exports.ids = [755];
exports.modules = {

/***/ 6064:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _db_mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6922);
/* harmony import */ var _models_course__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1778);


(0,_db_mongoose__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)();

const handler = async (req, res) => {
  // Find the course with a given code and university
  if (req.method === 'GET') {
    const {
      uni,
      code
    } = req.query;

    try {
      const query = await _models_course__WEBPACK_IMPORTED_MODULE_1__/* .default.aggregate */ .Z.aggregate([{
        $facet: {
          totalData: [{
            $match: {
              university: uni,
              pageId: code
            }
          }, {
            $lookup: {
              from: 'reviews',
              localField: '_id',
              foreignField: 'owner',
              as: 'reviews'
            }
          }, {
            // Get the number of reviews + the average review score
            $addFields: {
              reviewCount: {
                $size: '$reviews'
              },
              rating: {
                $ifNull: [{
                  $avg: '$reviews.course_rating'
                }, 0]
              }
            }
          }, {
            $project: {
              code: 1,
              title: 1,
              university: 1,
              faculty: 1,
              rating: 1,
              reviewCount: 1,
              term: 1,
              description: 1,
              url: 1,
              requirements: 1,
              assessments: 1
            }
          }, {
            $limit: 1
          }]
        }
      }]);
      const course = query[0].totalData[0]; // map to response

      const data = {
        id: course._id,
        code: course.code,
        title: course.title,
        university: course.university,
        faculty: course.faculty,
        rating: course.rating,
        numRatings: course.reviewCount,
        term: course.term,
        overview: course.description,
        url: course.url,
        requirements: course.requirements,
        assessments: course.assessments
      };
      res.status(200).json(data);
    } catch (e) {
      res.status(400).json(e);
    }
  }
};

/* harmony default export */ __webpack_exports__["default"] = (handler);

/***/ }),

/***/ 5619:
/***/ (function(module) {

"use strict";
module.exports = require("mongoose");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [692], function() { return __webpack_exec__(6064); });
module.exports = __webpack_exports__;

})();