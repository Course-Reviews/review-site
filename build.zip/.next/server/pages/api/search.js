(function() {
var exports = {};
exports.id = 198;
exports.ids = [198];
exports.modules = {

/***/ 6922:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connection = {};

async function connectDB() {
  if (connection.isConnected) {
    // Use current db connection
    return;
  } // Use new db connection


  const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true
  });
  connection.isConnected = db.connections[0].readyState;
  console.log(connection.isConnected);
}

/* harmony default export */ __webpack_exports__["Z"] = (connectDB);

/***/ }),

/***/ 8784:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _db_mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6922);

(0,_db_mongoose__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)();

const handler = async (req, res) => {
  if (req.method === 'GET') {
    res.json([]);
  }
};

/* harmony default export */ __webpack_exports__["default"] = (handler);

/***/ }),

/***/ 5619:
/***/ (function(module) {

"use strict";
module.exports = require("mongoose");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(8784));
module.exports = __webpack_exports__;

})();