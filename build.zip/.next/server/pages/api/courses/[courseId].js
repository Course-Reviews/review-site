(function() {
var exports = {};
exports.id = 489;
exports.ids = [489];
exports.modules = {

/***/ 2150:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _db_mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6922);
/* harmony import */ var _models_course__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1778);


(0,_db_mongoose__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)();

const handler = async (req, res) => {
  if (req.method === 'GET') {
    try {
      const courses = await _models_course__WEBPACK_IMPORTED_MODULE_1__/* .default.find */ .Z.find();
      res.status(200).json(courses);
    } catch (e) {
      res.status(400).json(e);
    }
  }
};

/* harmony default export */ __webpack_exports__["default"] = (handler);

/***/ }),

/***/ 5619:
/***/ (function(module) {

"use strict";
module.exports = require("mongoose");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [692], function() { return __webpack_exec__(2150); });
module.exports = __webpack_exports__;

})();