(function() {
var exports = {};
exports.id = 999;
exports.ids = [999];
exports.modules = {

/***/ 8379:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _db_mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6922);
/* harmony import */ var _models_course__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1778);


(0,_db_mongoose__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)();
const PAGE_SIZE = 25;

const handler = async (req, res) => {
  if (req.method === 'GET') {
    const {
      uni,
      stage
    } = req.query;
    const page = parseInt(`${req.query.page || 0}`); // construct match criteria

    const matchCriteria = {};

    if (stage) {
      matchCriteria.code = new RegExp(`.*\\s${stage}.*`, 'i');
    }

    if (uni) {
      matchCriteria.university = uni;
    }

    try {
      const query = await _models_course__WEBPACK_IMPORTED_MODULE_1__/* .default.aggregate */ .Z.aggregate([{
        $facet: {
          totalData: [{
            $match: matchCriteria
          }, {
            $lookup: {
              from: 'reviews',
              localField: '_id',
              foreignField: 'owner',
              as: 'reviews'
            }
          }, {
            // Get the number of reviews + the average review score
            $addFields: {
              reviewCount: {
                $size: '$reviews'
              },
              rating: {
                $ifNull: [{
                  $avg: '$reviews.course_rating'
                }, 0]
              }
            }
          }, {
            $project: {
              pageId: 1,
              code: 1,
              title: 1,
              university: 1,
              reviewCount: 1,
              rating: 1
            }
          }, {
            $sort: {
              code: 1
            }
          }, {
            $skip: PAGE_SIZE * page
          }, {
            $limit: PAGE_SIZE
          }],
          totalCount: [{
            $count: 'count'
          }]
        }
      }]); // Map to response object

      const data = {
        courses: query[0].totalData.map(c => ({
          rating: c.rating,
          numRatings: c.reviewCount,
          code: c.code,
          university: c.university,
          pageId: c.pageId,
          title: c.title
        })),
        pagination: {
          totalCount: query[0].totalCount[0].count,
          pageSize: PAGE_SIZE,
          page
        }
      };
      res.status(200).json(data);
    } catch (e) {
      res.status(400).json(e);
    }
  }
};

/* harmony default export */ __webpack_exports__["default"] = (handler);

/***/ }),

/***/ 5619:
/***/ (function(module) {

"use strict";
module.exports = require("mongoose");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [692], function() { return __webpack_exec__(8379); });
module.exports = __webpack_exports__;

})();